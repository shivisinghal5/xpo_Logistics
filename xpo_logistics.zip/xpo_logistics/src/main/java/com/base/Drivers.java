package com.base;

 

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


 

public class Drivers {

                public static WebDriver driver;
                public static String url="http://demo.borland.com/InsuranceWebExtJS/index.jsf";
 

                /**

                * sets the driver for initiate the browser

                *

                 * @param browser

                *            - is the browser name on which test will be run

                */

                public static void setDriver(String browser) {

                                /**

                                * Driver are kept in Drivers folder, paste the driver according to your

                                * browser version Ex : here chrome driver is for 73 version

                                */

                                try {

                                                System.out.println("Browser = " + browser);

                                                if (browser.equalsIgnoreCase("chrome")) {

                                                                System.setProperty("webdriver.chrome.driver",

                                                                                                "Drivers\\chromedriver.exe");

                                                                driver = new ChromeDriver();

                                                                System.out.println("Chrome browser is going to start");

                                                } else if (browser.equalsIgnoreCase("IE")

                                                                                || (browser.equalsIgnoreCase("internet Explorer"))) {

                                                                System.setProperty("webdriver.ie.driver",

                                                                                                "Drivers\\internetExplolerdriver.exe");

                                                                driver = new InternetExplorerDriver();

                                                                System.out.println("Internet Explorer browser is going to start");

                                                } else if (browser.equalsIgnoreCase("firefox")

                                                                                || (browser.equalsIgnoreCase("mozilla"))) {

                                                                System.setProperty("webdriver.gecko.driver",

                                                                                                "Drivers\\geckodriver.exe");

                                                                driver = new FirefoxDriver();

                                                                System.out.println("Firefox browser is going to start");

                                                } else {

                                                                System.setProperty("webdriver.chrome.driver",

                                                                                                "Drivers\\chromedriver.exe");

                                                                driver = new ChromeDriver();

                                                                System.out.println("The given user input is wrong so by default Chrome is going to initiate");

                                                }

                                                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                                                driver.get(url);

                                                System.out.println("Entered the url : " +url);

                                                driver.manage().window().maximize();

                                                System.out.println("Maximize the window");

                                                driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

                                } catch (Exception e) {

                                	System.out.println("Not able to initiate the browser : " + browser);

                                }

                }

}