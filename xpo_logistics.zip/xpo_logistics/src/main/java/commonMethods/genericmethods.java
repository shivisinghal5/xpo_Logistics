package commonMethods;

import java.io.FileReader;

import java.util.List;

import java.util.Properties;

import java.util.Set;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;

import org.openqa.selenium.By;

import org.openqa.selenium.ElementNotVisibleException;

import org.openqa.selenium.JavascriptExecutor;

import org.openqa.selenium.NoAlertPresentException;

import org.openqa.selenium.NoSuchElementException;

import org.openqa.selenium.NoSuchFrameException;

import org.openqa.selenium.NoSuchWindowException;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.support.ui.WebDriverWait;
import com.base.Drivers;

public class genericmethods extends Drivers {

	public static Properties prop;

	/*
	 * it will find the elements from properties file
	 * 
	 * @param key - is the name of locator. Example
	 * username=xpath://*[@id='abc']. username is the key user have to give
	 * 
	 * @return - it will return the element
	 */

	public static WebElement getLocator(String key, String fileName) {

		WebElement ele;

		String value = readProperties(key, fileName);

		String str[] = value.split(":");

		String locator = str[0];

		String locator_value = str[1];

		switch (locator) {

		case "id":

			ele = driver.findElement(By.id(locator_value));

			break;

		case "class":

			ele = driver.findElement(By.className(locator_value));

			break;

		case "linktext":

			ele = driver.findElement(By.linkText(locator_value));

			break;

		case "css":

			ele = driver.findElement(By.cssSelector(locator_value));

			break;

		case "tag":

			ele = driver.findElement(By.tagName(locator_value));

			break;

		case "partial link":

			ele = driver.findElement(By.partialLinkText(locator_value));

			break;

		case "name":

			ele = driver.findElement(By.name(locator_value));

			break;

		case "xpath":

			ele = driver.findElement(By.xpath(locator_value));

			break;

		default:

			ele = driver.findElement(By.xpath(locator_value));

			break;

		}

		highlightElements(ele);

		return ele;

	}

	/**
	 * this method is for get the values from properties file
	 * @param key
	 *            - is the name of locator. Example
	 *            username=xpath://*[@id='abc']. username is the key user have
	 *            to give
	 * 
	 * @param fileName
	 *            - it is the properties file name
	 * @return it will return the value of given key
	 */

	public static String readProperties(String key, String fileName) {

		try {

			/*FileReader file = new FileReader(

					"src/test/resources/properties_Files/" + fileName

							+ ".properties");*/
			FileReader file = new FileReader(

					"xpo_logistics/properties_Files/" + fileName

							+ ".properties");

			prop = new Properties();

			prop.load(file);

		} catch (Exception e) {

			System.out.println(fileName + ".properties file does not found " + e);

		}

		String value = prop.getProperty(key);

		return value;

	}

	/**
	 * 
	 * this function will highlight the given element on screen
	 *
	 * 
	 * 
	 * @param ele
	 * 
	 *            - is the value to locator
	 * 
	 */

	public static void highlightElements(WebElement ele) {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript(

				"arguments[0].setAttribute('style', 'background: none; border: 2px solid blue;');",

				ele);

	}

	/**
	 * 
	 * this method is for implicit wait
	 *
	 * 
	 * 
	 * @param waitTime
	 * 
	 *            - is the value of wait time in seconds
	 * 
	 */

	public static void implicitWait(int waitTime) {

		System.out.println("Wait for " + waitTime + " secods");

		driver.manage().timeouts().implicitlyWait(waitTime, TimeUnit.SECONDS);

	}

	/**
	 * 
	 * this method will return the text element of given element
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - is the locator name
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name in which element is present
	 * 
	 * @return - it will return the string value
	 * 
	 */

	public static String getText(String element, String propFileName) {

		String text = getLocator(element, propFileName).getText();

		return text;

	}

	public static void close() {

		driver.quit();

		System.out.println("Closed the browser");

	}

	/**
	 * 
	 * this method will check for the radiobutton/checkbox is selected or not
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - it is the locator value
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 * @return it will return true if radiobutton/checkbox is already selected
	 * 
	 *         else false
	 * 
	 */

	public static boolean isSelected(String element, String propFileName) {

		boolean result = getLocator(element, propFileName).isSelected();

		if (result == true) {

			System.out.println("Element : " + element + " is already selected");

		} else {

			System.out.println("Element : " + element + " is not selected");

		}

		return result;

	}

	/**
	 * this method will check for the webelement is enabled or not
	 * @param element
	 *            - it is the locator value
	 * @param propFileName
	 *            - it is the properties file name
	 * @return it will return true if value will enabled otherwise false
	 */

	public static boolean isEnabled(String element, String propFileName) {

		boolean result = getLocator(element, propFileName).isEnabled();

		if (result == true) {

			System.out.println("Element : " + element + " is enabled");

		} else {

			System.out.println("Element : " + element + " is not enabled");

		}

		return result;

	}

	/**
	 * 
	 * this method will check for the webelement is displaying or not
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - it is the locator value
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 * @return it will return true if value will display otherwise false
	 * 
	 */

	public static boolean isDisplayed(String element, String propFileName) {

		boolean isPresent = true;

		try {

			isPresent = getLocator(element, propFileName).isDisplayed();

		} catch (NoSuchElementException e) {

			isPresent = false;

		}

		return isPresent;

	}

	/**
	 *
	 * 
	 * 
	 * @param accept_dismiss
	 * 
	 *            - user can give "accept" or "dismiss" for the alert
	 *
	 * 
	 * 
	 */

	public static void alerthandling(String accept_dismiss) {

		try {

			Alert alert = driver.switchTo().alert();

			switch (accept_dismiss) {

			case "accept":

				alert.accept();

				System.out.println("Accepted the Alert");

				driver.switchTo().defaultContent();

				implicitWait(5);

				break;

			case "dismiss":

				alert.dismiss();

				driver.switchTo().defaultContent();

				System.out.println("Dismissed the alert");

				implicitWait(5);

				break;

			default:

				System.out.println("Please give the right input for alert");

				break;

			}

		} catch (NoAlertPresentException e) {

			System.out.println("No Alert present on webpage " + e);

		}

	}

	/**
	 * 
	 * this method is for get the value of alert
	 *
	 * 
	 * 
	 * @return - it will return the alert text as string
	 * 
	 */

	public static String getAlertText() {

		String alertText;

		try {

			alertText = driver.switchTo().alert().getText();

			System.out.println("Value of alert text is :" + alertText);

			return alertText;

		} catch (NoAlertPresentException e) {

			System.out.println("No such alert present on webpage");

			alertText = null;

		}

		return alertText;

	}

	/**
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - value of locator
	 * 
	 * @param method
	 * 
	 *            - by text or value or index
	 * 
	 * @param value
	 * 
	 *            - value to be select Ex:
	 * 
	 *            selectFromDropdown("usernamexpath","text","test")
	 * 
	 */

	public static void selectFromDropDown(String element, String propFileName,

			String selectby, String value) {

		try {

			WebElement ele = getLocator(element, propFileName);

			Select s = new Select(ele);

			switch (selectby) {

			case "text":

				s.selectByVisibleText(value);

				break;

			case "value":

				s.selectByValue(value);

				break;

			case "index":

				int arg = Integer.parseInt(value);

				s.selectByIndex(arg);

				break;

			default:

				System.out.println("you have not given correct input values for selecting the value from dropdown");

				break;

			}

		} catch (Exception e) {

			System.out.println("Not able to Select value from dropdown " + e);

		}

	}

	// this method will print the all values of a dropdown

	public static void printValuesOfDropDown(String element, String propFileName) {

		WebElement ele = getLocator(element, propFileName);

		Select s = new Select(ele);

		List<WebElement> allValues = s.getOptions();

		int count = allValues.size();

		System.out.println("Number of values in dropdown  :- " + count + "\n");

		for (int i = 1; i < allValues.size(); i++) {

			String Values = allValues.get(i).getText();

			System.out.println("Values in the dropdown are : " + Values);

		}

	}

	/**
	 * 
	 * this method is for hover over the element
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - it is the locator value
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 */

	public static void moveToElement(String element, String propFileName) {

		try {

			WebElement ele = getLocator(element, propFileName);

			Actions act = new Actions(driver);

			act.moveToElement(ele).perform();

			System.out.println("Hover over the element " + element);

		} catch (Exception e) {

			System.out.println("Not able to hover over the element : " + element);

		}

	}

	/**
	 * 
	 * this method is for hover over the element and click on it
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - it is the locator value
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 */

	public static void moveToElementClick(String element, String propFileName) {

		WebElement ele = getLocator(element, propFileName);

		Actions act = new Actions(driver);

		act.moveToElement(ele).click().perform();

		// Log.info("Hover over the element " + element + " and clicked on it");

	}

	/**
	 * 
	 * this method will return the current title of webpage
	 *
	 * 
	 * 
	 * @return -it will return the title as string
	 * 
	 */

	public static String getTitle() {

		String title = null;

		try {

			title = driver.getTitle();

		} catch (Exception e) {

			// Log.error("Not able to get title of the page " + e);

		}

		return title;

	}

	// it will scroll the page to the bottom

	public static void scrollingToBottomOfAPage() {

		((JavascriptExecutor) driver)

				.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		// Log.info("Scrolling down to the page");

	}

	/**
	 * 
	 * it will scroll the page to the given element
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - it is the locator value
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 */

	public static void scrollToElement(String element, String propFileName) {

		WebElement ele = getLocator(element, propFileName);

		((JavascriptExecutor) driver).executeScript(

				"arguments[0].scrollIntoView();", ele);

		// Log.info("Scrolling down to the element " + element);

	}

	/**
	 * 
	 * this method will switch to frame
	 *
	 * 
	 * 
	 * @param name_id_index
	 * 
	 *            - frame can be switched by name/id/index
	 * 
	 * @param value
	 * 
	 *            - it is the value of frame
	 * 
	 */

	public static void switchToFrame(String name_id_index, String value) {

		try {

			switch (name_id_index) {

			case "name":

				driver.switchTo().frame(value);

				// Log.info("Switched to frame : " + value + " by "+
				// name_id_index);

				break;

			case "id":

				driver.switchTo().frame(value);

				// Log.info("Switched to frame : " + value + " by "+
				// name_id_index);

				break;

			case "index":

				int index = Integer.parseInt(value);

				driver.switchTo().frame(index);

				System.out.println("Switched to frame : " + value + " by "

						+ name_id_index);

				break;

			default:

				System.out.println("by Default switching to frame by id");

				driver.switchTo().frame(name_id_index);

				break;

			}

		} catch (NoSuchFrameException e) {

			System.out.println("No Such frame present " + e);

		}

	}

	// this method will switch to parent frame

	public static void switchToParentframe() {

		driver.switchTo().parentFrame();

		System.out.println("Switched to parent Frame");

	}

	// this method will wait for 30 seconds for the given element to be display

	public static void WaitForElementToBeVisible(String element,

			String propFileName) {

		try {

			WebDriverWait wait = new WebDriverWait(driver, 30);

			wait.until(ExpectedConditions.visibilityOf(genericmethods

					.getLocator(element, propFileName)));

		} catch (ElementNotVisibleException e) {

			System.out.println("Element : " + element + " is not visible");

		}

	}

	// this method will wait for the element to be clickable

	public static void WaitForElementToBeClickable(String element,

			String propFileName) {

		try {

			WebDriverWait wait = new WebDriverWait(driver, 30);

			wait.until(

					ExpectedConditions.elementToBeClickable(genericmethods

							.getLocator(element, propFileName)))
					.click();

		} catch (Exception e) {

			System.out.println("Element : " + element + " is not Clickable " + e);

		}

	}

	// this method will wait for the alert to be display

	public static void waitforAlertToDisplay() {

		try {

			WebDriverWait wait = new WebDriverWait(driver, 15);

			wait.until(ExpectedConditions.alertIsPresent());

		} catch (NoAlertPresentException e) {

			System.out.println("No such alert present " + e);

		}

	}

	/**
	 * 
	 * this method will wait the given title to be visible
	 *
	 * 
	 * 
	 * @param title
	 * 
	 *            - it is the string value of title for which driver will wait
	 * 
	 *            for 20 seconds
	 * 
	 */

	public static void WaitForTitle(String title) {

		WebDriverWait wait = new WebDriverWait(driver, 20);

		wait.until(ExpectedConditions.titleIs(title));

	}

	/**
	 * @param element
	 * 
	 *            - is the locator name in properties file
	 * 
	 * @param proFileName
	 * 
	 *            - it is the properties file name
	 * 
	 * @param text
	 * 
	 *            - this value will be searched in the webtable
	 * 
	 * @return - if value found in table then it will return true else false
	 * 
	 */

	/*
	 * public static boolean findTextinTable(String element, String
	 * propFileName,
	 * 
	 * String text) {
	 * 
	 * boolean result = false;
	 * 
	 * WebElement mytable = getLocator(element, propFileName);
	 * 
	 * List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
	 * 
	 * int rows_count = rows_table.size();
	 * 
	 * 
	 * 
	 * for (int row = 0; row < rows_count; row++) {
	 * 
	 * List<WebElement> Columns_row = rows_table.get(row).findElements(
	 * 
	 * By.tagName("td"));
	 * 
	 * int columns_count = Columns_row.size();
	 * 
	 * for (int column = 0; column < columns_count; column++) {
	 * 
	 * String celltext = Columns_row.get(column).getText();
	 * 
	 * if (celltext.equalsIgnoreCase(text)) {
	 * 
	 * Log.info("Given text " + text
	 * 
	 * + " is found in table at column " + column + " in "
	 * 
	 * + row + " row");
	 * 
	 * result = true;
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 * 
	 * return result;
	 * 
	 * }
	 * 
	 * 
	 * 
	 * // this method will return the number of rows in a table
	 * 
	 * public static int getNumberOfrows(String element, String propFileName) {
	 * 
	 * int rows_count = 0;
	 * 
	 * try {
	 * 
	 * WebElement mytable = getLocator(element, propFileName);
	 * 
	 * List<WebElement> rows_table = mytable
	 * 
	 * .findElements(By.tagName("tr"));
	 * 
	 * rows_count = rows_table.size();
	 * 
	 * } catch (Exception e) {
	 * 
	 * Log.info("Not able to return the number of rows " + e);
	 * 
	 * }
	 * 
	 * if (rows_count == 0) {
	 * 
	 * return rows_count;
	 * 
	 * } else {
	 * 
	 * return rows_count - 1;
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 */

	// this method will return the selected value from the dropdown

	public static String getTextFromDropdown(String element, String propFileName) {

		WebElement ele = getLocator(element, propFileName);

		Select select = new Select(ele);

		WebElement option = select.getFirstSelectedOption();

		String defaultItem = option.getText();

		return defaultItem;

	}

	/**
	 * 
	 * it will select the given date from calender
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - is the locator name in properties file
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 * @param date
	 * 
	 *            - give the date to be select(ex- 15/06/2019)
	 * 
	 */

	public static void SelectDatefromCalender(String element,

			String propFileName, String date) {

		try {

			String[] extracteddate = date.split("/");

			String date_only = extracteddate[0];

			WebElement mytable = getLocator(element, propFileName);

			List<WebElement> rows_table = mytable

					.findElements(By.tagName("tr"));

			int rows_count = rows_table.size();

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_table.get(row)

						.findElements(By.tagName("td"));

				System.out.println(Columns_row.toString());

				int columns_count = Columns_row.size();

				for (int column = 0; column < columns_count; column++) {

					String celltext = Columns_row.get(column).getText();

					if (celltext.equalsIgnoreCase(date_only)) {

						System.out.println("Given date is found in Calender at column "

								+ column + " in " + row

								+ " row, and clicked on it");

						Columns_row.get(column).click();

						break;

					}

				}

			}

		} catch (Exception e) {

			System.out.println("Not able to select date from calender " + e);

		}

	}

	/**
	 * 
	 * this method will check for the text in table and click on a column(
	 * 
	 * column number is given by user)
	 *
	 * 
	 * 
	 * @param element
	 * 
	 *            - locator for table
	 * 
	 * @param propFileName
	 * 
	 *            - it is the properties file name
	 * 
	 * @param text
	 * 
	 *            - this is the text to be verify in table
	 * 
	 * @param columnnum
	 * 
	 *            - number of columns which you want to perform click
	 * 
	 */

	public static void verifyTextandClick(String element, String propFileName,

			String text, int columnnum) {

		WebElement mytable = getLocator(element, propFileName);

		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));

		int rows_count = rows_table.size();

		for (int row = 0; row < rows_count; row++) {

			List<WebElement> Columns_row = rows_table.get(row).findElements(

					By.tagName("td"));

			int columns_count = Columns_row.size();

			for (int column = 0; column < columns_count; column++) {

				String celltext = Columns_row.get(column).getText();

				if (celltext.equalsIgnoreCase(text)) {

					System.out.println("Given Text is found in table at column " + column

							+ " in " + row + " row");

					Columns_row.get(columnnum).click();

				}

			}

		}

	}

	/**
	 * 
	 * this method is for window handling
	 *
	 * 
	 * 
	 * @param title
	 * 
	 *            : it is target window title
	 * 
	 */

	public static void windowHandling(String title) {

		try {

			Set<String> windows = driver.getWindowHandles();

			for (String s : windows) {

				driver.switchTo().window(s);

				if (driver.getTitle().equalsIgnoreCase(title)) {

					System.out.println("Switched to the target window");

				}

			}

		} catch (NoSuchWindowException e) {

			System.out.println("No such window found " + e);

		}

	}

	/*
	 * 
	 * this method will find the element by xpath and return the element
	 * 
	 */

	public static WebElement findElementByXpath(String path) {

		WebElement ele = driver.findElement(By.xpath(path));

		return ele;

	}

	/*
	 * 
	 * this method will return the attribute of an element
	 * 
	 */

	public static String getAttribute(String element, String propFileName,

			String attribute) {

		String value = getLocator(element, propFileName)

				.getAttribute(attribute);

		return value;

	}

	/*
	 * 
	 * this method is to click on a element by javascript
	 * 
	 */

	public static void javascriptClick(String element, String propFileName) {

		WebElement element1 = getLocator(element, propFileName);

		JavascriptExecutor executor = (JavascriptExecutor) driver;

		executor.executeScript("arguments[0].click();", element1);

	}

}
