package pom_classes;

public class AutoQuote {

}
